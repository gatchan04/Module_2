﻿#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-
#------------------------------------------------------------------------------#
#--________________________________---------------____----------___------------#
#-| name:___MainLibVar_Main_______|--------------/-------|--|--/---------------#
#-| date:___31/03/2019____________|--------------|-------|--|--|---------------#
#-| otor:___ScroogeMcDuck_________|--------------|-___---|--|--\___------------#
#-|_______________________________|--------------|---|---|--|------\-----------#
#------------------------------------------------|---|---|--|------|-----------#
#------------------------------------------------\___/---\__/---___/-----------#
#------------------------------------------------------------------------------#
#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-

#_Modules_####################################################################_#
from Module_2_Lib import *
from Module_2_Var import *

#_Initialisation_#############################################################_#
pygame.display.set_icon(Logo)
pygame.display.set_caption("Module 2")

pygame.mixer.music.play(1)



#_Boucle_#####################################################################_#
while Marche:
    horloge.tick(Max_FPS)
    print(horloge.get_fps())
    for event in pygame.event.get():
        if event.type == QUIT:
            Marche  = False
        if event.type == KEYDOWN:
            if event.key == K_ESCAPE:
                Marche = False

##    print(joystick_count)
    #Intro
    if Etat_Jeu == 0:
        classe_terrain.affiche(fenetre)
        classe_Alicia.affiche(fenetre)
        classe_Glibili.affiche(fenetre)
        classe_Intro.Affiche(fenetre)
        if classe_Intro.x < -550:
            Etat_Jeu = 1

        if event.type == KEYDOWN:
            if event.key == K_RETURN:
                Etat_Jeu = 1



    #Jeu
    if Etat_Jeu == 1:
    ##    if pygame.mouse.get_pressed()[0]:
    ##        for i in range(20):
    ##            listeParticule.append(Particule(newmPos[0],newmPos[1]))

    ##    longueurListe   = len(listeParticule)
    ##    for i in listeParticule:
    ##        i.calculPos()
    ##
    ##
    ##    indexASupp = []
    ##    for i in range(longueurListe):
    ##        if not listeParticule[i].isAllume():
    ##            indexASupp.append(i)
    ##    indexASupp.reverse()
    ##    for i in indexASupp:
    ##        listeParticule.pop(i)

        surfaceContourCouleur = pygame.Surface((320,180))

        fenetre = pygame.Surface(FausseResolu)
        fenetre.fill((0,0,0))
    ##    pygame.draw.circle(fenetre,(255,0,0),newmPos,2)


    ##    for i in listeParticule:
    ##        i.affiche(fenetre)
    ##        i.setContour(surfaceContourCouleur)

        fenetre.blit(surfaceContourCouleur,(0,0),None,BLEND_ADD)
        classe_terrain.affiche(fenetre)

        Commandes_Jeu()
        nuit.fill((classe_Alicia.Score+classe_Glibili.Score,classe_Alicia.Score+classe_Glibili.Score,classe_Alicia.Score+classe_Glibili.Score))
        spot_ecran.fill((classe_Alicia.Score+classe_Glibili.Score,classe_Alicia.Score+classe_Glibili.Score,classe_Alicia.Score+classe_Glibili.Score))
        pygame.draw.circle(spot_persos,(classe_Alicia.Score+classe_Glibili.Score,classe_Alicia.Score+classe_Glibili.Score,classe_Alicia.Score+classe_Glibili.Score),(25,25),25)
        fenetre.blit(nuit,(0,0),None,BLEND_SUB)
        if classe_Alicia.Score+classe_Glibili.Score > 80:
            fenetre.blit(spot_persos,(classe_Alicia.position.move(-17,-5)),None,BLEND_ADD)
            fenetre.blit(spot_persos,(classe_Glibili.position.move(-16,-5)),None,BLEND_ADD)
        fenetre.blit(spot_ecran,(classe_terrain.xecran+2,classe_terrain.yecran+7),None,BLEND_ADD)

        classe_Alicia.affiche(fenetre)
##        classe_Glibili.IA()
        classe_Glibili.affiche(fenetre)
        if classe_Alicia.Score < Score_Victoire and classe_Glibili.Score < Score_Victoire:
            classe_balle.affiche(fenetre)
        elif classe_Alicia.Score >= Score_Victoire or classe_Glibili.Score >= Score_Victoire:
            if event.type == KEYDOWN:
                if event.key == K_RETURN:
                    Etat_Jeu = 2


        newmPos = (classe_balle.position[0]+10,classe_balle.position[1]+10)
        if classe_balle.super_on:
            for i in range(20):
                listeParticule.append(Particule(newmPos[0],newmPos[1]))

        longueurListe   = len(listeParticule)
        for i in listeParticule:
            i.calculPos()


        indexASupp = []
        for i in range(longueurListe):
            if not listeParticule[i].isAllume():
                indexASupp.append(i)
        indexASupp.reverse()
        for i in indexASupp:
            listeParticule.pop(i)


    ##    pygame.draw.circle(fenetre,(255,0,0),newmPos,2)


        for i in listeParticule:
            i.affiche(fenetre)
            i.setContour(surfaceContourCouleur)

    ##        classe_particule = Particule(classe_balle.position[0],classe_balle.position[1])
    ##        classe_particule.setContour(fenetre)
    ##        classe_particule.affiche(fenetre)


    #Credits
    if Etat_Jeu == 2:
        fenetre.fill((0,0,0))
        classe_credits.Affiche(fenetre)


##    pygame.draw.circle(fenetre,(255,0,0),newmPos,2)
    pygame.transform.scale(fenetre,Resolution,ecran)
    pygame.display.flip()
pygame.quit()