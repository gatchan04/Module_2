﻿#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-
#------------------------------------------------------------------------------#
#--________________________________---------------____----------___------------#
#-| name:___MainLibVar_Lib________|--------------/-------|--|--/---------------#
#-| date:___31/03/2019____________|--------------|-------|--|--|---------------#
#-| otor:___ScroogeMcDuck_________|--------------|-___---|--|--\___------------#
#-|_______________________________|--------------|---|---|--|------\-----------#
#------------------------------------------------|---|---|--|------|-----------#
#------------------------------------------------\___/---\__/---___/-----------#
#------------------------------------------------------------------------------#
#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-

#_Modules_####################################################################_#
import pygame

from Module_2_Var   import *
from pygame.locals  import *
from math           import *
from time           import time
from random         import *

#_Initialisation_#############################################################_#
pygame.init()

ecran   = pygame.display.set_mode(Resolution)
horloge = pygame.time.Clock()
fenetre = pygame.Surface(FausseResolu)

pygame.mouse.set_visible(False)

#_Images_#####################################################################_#
fond = pygame.image.load("Images\Fond_module2.png").convert_alpha()
for i in range(3):
    trumpy.append(pygame.image.load("Images\img_trump_"+str(i)+".png").convert_alpha())
for i in range(2):
    Couple_M.append(pygame.image.load("Images\Couple_M_"+str(i)+".png").convert_alpha())
for i in range(2):
    popman.append(pygame.image.load("Images\popman_"+str(i)+".png").convert_alpha())
for i in range(2):
    Couple_O.append(pygame.image.load("Images\Couple_O_"+str(i)+".png").convert_alpha())
for i in range(2):
    Poussette_girl.append(pygame.image.load("Images\Poussete_girl_"+str(i)+".png").convert_alpha())
for i in range(2):
    monsieur_D.append(pygame.image.load("Images\Monsieur_D_"+str(i)+".png").convert_alpha())
for i in range(2):
    Chaton.append(pygame.image.load("Images\chat_"+str(i)+".png").convert_alpha())
for i in range(2):
    Boss.append(pygame.image.load("Images\Boss_"+str(i)+".png").convert_alpha())
for i in range(2):
    Pervilo.append(pygame.image.load("Images\Pervilo_"+str(i)+".png").convert_alpha())
for i in range(2):
    Murata_girl.append(pygame.image.load("Images\Murata_girl_"+str(i)+".png").convert_alpha())
for i in range(2):
    Magic_viny.append(pygame.image.load("Images\M.viny_"+str(i)+".png").convert_alpha())
for i in range(2):
    McNieps.append(pygame.image.load("Images\McNieps_"+str(i)+".png").convert_alpha())
for i in range(2):
    Pervagus.append(pygame.image.load("Images\Pervagus_"+str(i)+".png").convert_alpha())
for i in range(2):
    Escargod.append(pygame.image.load("Images\Escargod_"+str(i)+".png").convert_alpha())
for i in range(2):
    Incroyable.append(pygame.image.load("Images\Incroyable_"+str(i)+".png").convert_alpha())
for i in range(2):
    Onchix.append(pygame.image.load("Images\Onchix_"+str(i)+".png").convert_alpha())
for i in range(2):
    Edupy.append(pygame.image.load("Images\Edupy_"+str(i)+".png").convert_alpha())
for i in range(2):
    PixelBoy.append(pygame.image.load("Images\PixelBoy_"+str(i)+".png").convert_alpha())
for i in range(2):
    Cornichon.append(pygame.image.load("Images\Cornichon_"+str(i)+".png").convert_alpha())
for i in range(2):
    Porco_rosso.append(pygame.image.load("Images\Porco_rosso_"+str(i)+".png").convert_alpha())
for i in range(5):
    Alicia.append(pygame.image.load("Images\Alicia_"+str(i)+".png").convert_alpha())
for i in range(5):
    Glibili.append(pygame.image.load("Images\Glibili_"+str(i)+".png").convert_alpha())
for i in range(5):
    Ecran_Affichage.append(pygame.image.load("Images\Ecran_affichage_"+str(i)+".png").convert_alpha())
for i in range(11):
    Score.append(pygame.image.load("Images\Affichage_"+str(i)+".png").convert_alpha())
Logo = pygame.image.load("Images\Logo_module2.png").convert_alpha()
balle = pygame.image.load("Images\Balle.png").convert_alpha()

nuit = pygame.Surface((1280,720))
spot_persos = pygame.Surface((50,50))
spot_ecran = pygame.Surface((51,13))


#_Sons
Hit = pygame.mixer.Sound("Hit_Hurt3.wav")
Super_Hit = pygame.mixer.Sound("Hit_Hurt4.wav")
pygame.mixer.music.load("test1.wav")
pygame.mixer.music.queue("Boss_Theme.wav")

#Ecriture
Titre = pygame.font.Font('PF_Font.ttf',18)

# Initialisation de la manette
pygame.joystick.init()
joystick_count = pygame.joystick.get_count()
joysticks = [pygame.joystick.Joystick(x) for x in range(pygame.joystick.get_count())]
for i in range(joystick_count):
    joysticks[i].init()

#_Fonctions_##################################################################_#

def Credits(screen):
    screen.blit(Titre.render("Merci d'avoir joué à module 2",0,(255,255,255)),(50,10))

def Commandes_Jeu():
    Touches = pygame.key.get_pressed()

    if joystick_count >= manette_1+1:

##        if joystick.get_hat(0)[0] == 1 and joystick.get_hat(0)[1] == 1: # Déplacement DiagHautDroite
##            classe_Alicia.DiagHautDroite()
##        elif joystick.get_hat(0)[0] == 1 and joystick.get_hat(0)[1] == -1: # Déplacement DiagBasDroite
##            classe_Alicia.DiagBasDroite()
##        elif joystick.get_hat(0)[0] == -1 and joystick.get_hat(0)[1] == 1: # Déplacement DiagHautGauche
##            classe_Alicia.DiagHautGauche()
##        elif joystick.get_hat(0)[0] == -1 and joystick.get_hat(0)[1] == -1: # Déplacement DiagBasGauche
##            classe_Alicia.DiagBasGauche()
##
##
##        elif joystick.get_hat(0)[0] == 1: # Déplacement droite
##            classe_Alicia.Droite()
##        elif joystick.get_hat(0)[0] == -1: # Déplacement gauche
##            classe_Alicia.Gauche()
##        elif joystick.get_hat(0)[1] == 1: # Déplacement haut
##            classe_Alicia.Haut()
##        elif joystick.get_hat(0)[1] == -1: # Déplacement Bas
##            classe_Alicia.Bas()

        if joysticks[manette_1].get_axis(0) > 0.1 and joysticks[manette_1].get_axis(1) < -0.1: # Déplacement DiagHautDroite
            classe_Alicia.DiagHautDroite()
        elif joysticks[manette_1].get_axis(0) > 0.1 and joysticks[manette_1].get_axis(1) > 0.1: # Déplacement DiagBasDroite
            classe_Alicia.DiagBasDroite()
        elif joysticks[manette_1].get_axis(0) < -0.1 and joysticks[manette_1].get_axis(1) < -0.1: # Déplacement DiagHautGauche
            classe_Alicia.DiagHautGauche()
        elif joysticks[manette_1].get_axis(0) < -0.1 and joysticks[manette_1].get_axis(1) > 0.1: # Déplacement DiagBasGauche
            classe_Alicia.DiagBasGauche()

        elif joysticks[manette_1].get_axis(0) > 0.1: # Déplacement droite
            classe_Alicia.Droite()
        elif joysticks[manette_1].get_axis(0) < -0.1: # Déplacement gauche
            classe_Alicia.Gauche()
        elif joysticks[manette_1].get_axis(1) < -0.1: # Déplacement haut
            classe_Alicia.Haut()
        elif joysticks[manette_1].get_axis(1) > 0.1: # Déplacement Bas
            classe_Alicia.Bas()

        if joysticks[manette_1].get_button(0) == 1: # Coup droit
            classe_Alicia.TirDroite()
        if joysticks[manette_1].get_button(1) == 1: # Coup gauche
            classe_Alicia.TirGauche()
        if joysticks[manette_1].get_button(2) == 1: # Suuper
            classe_Alicia.Super()

    if joystick_count >= manette_2+1:
        if joysticks[manette_2].get_axis(0) > 0.1 and joysticks[manette_2].get_axis(1) < -0.1: # Déplacement DiagHautDroite
            classe_Glibili.DiagHautDroite()
        elif joysticks[manette_2].get_axis(0) > 0.1 and joysticks[manette_2].get_axis(1) > 0.1: # Déplacement DiagBasDroite
            classe_Glibili.DiagBasDroite()
        elif joysticks[manette_2].get_axis(0) < -0.1 and joysticks[manette_2].get_axis(1) < -0.1: # Déplacement DiagHautGauche
            classe_Glibili.DiagHautGauche()
        elif joysticks[manette_2].get_axis(0) < -0.1 and joysticks[manette_2].get_axis(1) > 0.1: # Déplacement DiagBasGauche
            classe_Glibili.DiagBasGauche()

        elif joysticks[manette_2].get_axis(0) > 0.1: # Déplacement droite
            classe_Glibili.Droite()
        elif joysticks[manette_2].get_axis(0) < -0.1: # Déplacement gauche
            classe_Glibili.Gauche()
        elif joysticks[manette_2].get_axis(1) < -0.1: # Déplacement haut
            classe_Glibili.Haut()
        elif joysticks[manette_2].get_axis(1) > 0.1: # Déplacement Bas
            classe_Glibili.Bas()

        if joysticks[manette_2].get_button(0) == 1: # Coup droit
            classe_Glibili.TirDroite()
        if joysticks[manette_2].get_button(1) == 1: # Coup gauche
            classe_Glibili.TirGauche()
        if joysticks[manette_2].get_button(2) == 1: # Suuper
            classe_Glibili.Super()


    if Touches[K_d] and Touches[K_z]:
        classe_Alicia.DiagHautDroite()
    elif Touches[K_d] and Touches[K_s]:
        classe_Alicia.DiagBasDroite()
    elif Touches[K_q] and Touches[K_z]:
        classe_Alicia.DiagHautGauche()
    elif Touches[K_q] and Touches[K_s]:
        classe_Alicia.DiagBasGauche()
    elif Touches[K_d]: # Déplacement droite
        classe_Alicia.Droite()
    elif Touches[K_q]: # Déplacement gauche
        classe_Alicia.Gauche()
    elif Touches[K_z]: # Déplacement haut
        classe_Alicia.Haut()
    elif Touches[K_s]: # Déplacement Bas
        classe_Alicia.Bas()
    if Touches[K_k]:
        classe_Alicia.TirDroite()
    if Touches[K_o]:
        classe_Alicia.TirGauche()
    if Touches[K_p]:
        classe_Alicia.Super()


    if Touches[K_RIGHT] and Touches[K_UP]:
        classe_Glibili.DiagHautDroite()
    elif Touches[K_RIGHT] and Touches[K_DOWN]:
        classe_Glibili.DiagBasDroite()
    elif Touches[K_LEFT] and Touches[K_UP]:
        classe_Glibili.DiagHautGauche()
    elif Touches[K_LEFT] and Touches[K_DOWN]:
        classe_Glibili.DiagBasGauche()
    if Touches[K_RIGHT]:
        classe_Glibili.Droite()
    elif Touches[K_LEFT]:
        classe_Glibili.Gauche()
    elif Touches[K_UP]:
        classe_Glibili.Haut()
    elif Touches[K_DOWN]:
        classe_Glibili.Bas()
    if Touches[K_KP_ENTER]:
        classe_Glibili.TirDroite()
    if Touches[K_KP_PLUS]:
        classe_Glibili.TirGauche()
    if Touches[K_KP_MINUS]:
        classe_Glibili.Super()

def Collision(obj1,obj2):
    if obj1.right < obj2.left:
        return False
    if obj1.bottom < obj2.top:
        return False
    if obj1.left > obj2.right:
        return False
    if obj1.top > obj2.bottom:
        return False
    return True

#_Classes_####################################################################_#
class Particule:
    def __init__(self,x,y):
        self.taille     = randint(40,100)
        self.x          = x +10
        self.y          = y +10
        self.vx         = randint(-50,50)/30
        self.vy         = randint(-100,-20)/10

    def calculPos(self):
        self.vx        *= 0.99
        self.x         += self.vx
        self.vy        += 0
        self.vy        *= 0.99
        self.y         += self.vy
        self.taille    -= 2

    def isAllume(self):
        return self.taille > 10

    def affiche(self,surface):
        surf1    = pygame.Surface((80,80))
        surf1.set_colorkey((0,0,0))

        tailleCercle    = int(self.taille/10)

        if tailleCercle>0:
            if classe_balle.Vitesse_X > 1:
                pygame.draw.circle(surf1,(250,50,187),(40,40),tailleCercle)
            elif classe_balle.Vitesse_X < -1:
                pygame.draw.circle(surf1,(48,255,87),(40,40),tailleCercle)

        surface.blit(surf1,(self.x-40,self.y-40),None,BLEND_ADD)

    def setContour(self,surface):
        tailleCercle    = int(self.taille/10*4)
        pygame.draw.circle(surface,(250,4,4),(self.x,self.y),tailleCercle)


class terrain:
    def __init__(self):
        self.x                      = 0
        self.y                      = 0
        self.xtrumpy                = 146
        self.ytrumpy                = 150
        self.anim_trumpy            = 0
        self.xcouplem               = 0
        self.ycouplem               = 2
        self.compteurAnimcouplem    = 0
        self.xpopman                = 0
        self.ypopman                = 16
        self.compteurpopman         = 0
        self.xecran                 = 130
        self.yecran                 = 0
        self.anim_ecran             = 0
        self.xcoupleO               = 46
        self.ycoupleO               = 1
        self.xPoussette_girl        = 40
        self.yPoussette_girl        = 21
        self.xMonsieurD             = 89
        self.yMonsieurD             = 2
        self.xChaton                = 113
        self.yChaton                = 11
        self.xBoss                  = 77
        self.yBoss                  = 16
        self.xPervilo               = 98
        self.yPervilo               = 16
        self.xMurata_girl           = 150
        self.yMurata_girl           = 20
        self.xMagic_viny            = 300
        self.yMagic_viny            = 16
        self.xMcNieps               = 215
        self.yMcNieps               = 3
        self.xPervagus              = 190
        self.yPervagus              = -1
        self.xEscargod              = 125
        self.yEscargod              = 21
        self.xIncroyable            = 178
        self.yIncroyable            = 26
        self.xOnchix                = 280
        self.yOnchix                = 2
        self.xEdupy                 = 301
        self.yEdupy                 = 2
        self.xPixelBoy              = 220
        self.yPixelBoy              = 6
        self.xCornichon             = 255
        self.yCornichon             = 2


    def affiche(self,surface):
        self.compteurAnimcouplem = (self.compteurAnimcouplem+1)%60
        self.compteurpopman      = (self.compteurpopman+1)%60

        surface.blit(fond,(self.x,self.y))
        surface.blit(trumpy[self.anim_trumpy],(self.xtrumpy,self.ytrumpy))

        #Ecran d'affichage
        if classe_Alicia.Score == Score_Victoire:
            self.anim_trumpy = 2
            surface.blit(Ecran_Affichage[self.compteurAnimcouplem//30 + 1],(self.xecran,self.yecran))
        elif classe_Glibili.Score == Score_Victoire:
            self.anim_trumpy = 1
            surface.blit(Ecran_Affichage[self.compteurAnimcouplem//30 + 3],(self.xecran,self.yecran))
        else:
            surface.blit(Ecran_Affichage[self.anim_ecran],(self.xecran,self.yecran))
            #Score
            surface.blit(Score[10],(self.xecran,self.yecran))
            surface.blit(Score[classe_Glibili.Score%10],(self.xecran,self.yecran))
            surface.blit(Score[classe_Glibili.Score//10],(self.xecran-12,self.yecran))
            surface.blit(Score[classe_Alicia.Score%10],(self.xecran-30,self.yecran))
            surface.blit(Score[classe_Alicia.Score//10],(self.xecran-42,self.yecran))

            if classe_balle.direction == -1:
                self.anim_trumpy = 1
            elif classe_balle.direction == 1:
                self.anim_trumpy = 2
            else: self.anim_trumpy = 0

        #Décor gradins
        surface.blit(Couple_M[self.compteurAnimcouplem//30],(self.xcouplem,self.ycouplem))
        surface.blit(popman[self.compteurpopman//30],(self.xpopman,self.ypopman))
        surface.blit(Couple_O[self.compteurpopman//30],(self.xcoupleO,self.ycoupleO))
        surface.blit(Poussette_girl[self.compteurpopman//30],(self.xPoussette_girl,self.yPoussette_girl))
        surface.blit(monsieur_D[self.compteurpopman//30],(self.xMonsieurD,self.yMonsieurD))
        surface.blit(Chaton[self.compteurpopman//30],(self.xChaton,self.yChaton))
        surface.blit(pygame.transform.flip(Boss[self.compteurpopman//30],1,0),(self.xBoss,self.yBoss))
        surface.blit(Pervilo[self.compteurpopman//30],(self.xPervilo,self.yPervilo))
        surface.blit(Murata_girl[self.compteurpopman//30],(self.xMurata_girl,self.yMurata_girl))
        surface.blit(Edupy[self.compteurpopman//30],(self.xEdupy,self.yEdupy))
        surface.blit(Magic_viny[self.compteurpopman//30],(self.xMagic_viny,self.yMagic_viny))
        surface.blit(McNieps[self.compteurpopman//30],(self.xMcNieps,self.yMcNieps))
        surface.blit(Pervagus[self.compteurpopman//30],(self.xPervagus,self.yPervagus))
        surface.blit(Escargod[self.compteurpopman//30],(self.xEscargod,self.yEscargod))
        surface.blit(Incroyable[self.compteurpopman//30],(self.xIncroyable,self.yIncroyable))
        surface.blit(Onchix[self.compteurpopman//30],(self.xOnchix,self.yOnchix))
        surface.blit(PixelBoy[self.compteurpopman//30],(self.xPixelBoy,self.yPixelBoy))
        surface.blit(Cornichon[self.compteurpopman//30],(self.xCornichon,self.yCornichon))




        if classe_Alicia.Score == 100 or classe_Glibili.Score == 100:
            classe_Alicia.Score = 0
            classe_Glibili.Score = 0





class Alicia_Classe:
    def __init__(self):
        self.x                  = 50
        self.y                  = 100
        self.animation          = 0
        self.compteuranimation  = 0
        self.image              = Alicia
        self.position           = Alicia[self.animation].get_rect().move(self.x,self.y)
        self.rect               = Alicia[self.animation].get_rect().move(self.x,self.y)
        self.imgOmbre           = pygame.Surface((32,8))
        self.imgOmbre.fill((70,70,70))
        self.imgOmbre.set_colorkey((70,70,70))
        pygame.draw.ellipse(self.imgOmbre,(0,0,0),(0,0,32,8))
        self.imgOmbre.set_alpha(120)
        self.moncul             = 0
        self.vitesse_course     = 3
        self.Vitesse_X          = 0
        self.Vitesse_Y          = 0
        self.hitboxgauche       = pygame.Surface((30,40))
        self.hitboxgauche.fill((255,0,0))
        self.hitboxdroite       = pygame.Surface((20,10))
        self.hitboxdroite.fill((0,255,0))
        self.timer_attaque      = 0 #Compteur temps attaque
        self.timer_attaque_limite = 10 #Temps avant de pouvoir retoucher la balle
        self.mask               = pygame.mask.from_surface(self.hitboxgauche)
        self.Score              = 0  #Score marqué
        self.super              = 0  #Score encaissé avant d'utiliser la Super
        self.super_limite       = 10 #Score encaissé avant d'obtenir la Super
        self.lumiere            = pygame.Surface((30,30))
        self.lumiere.fill((0,0,0))
        self.lumiere.set_colorkey((0,0,0))
        self.intensite_lumiere = 100
        self.n = 0

    def Haut(self):
        self.Vitesse_Y          = -self.vitesse_course
        self.compteuranimation  = (self.compteuranimation+1)%10

    def Bas(self):
        self.Vitesse_Y          = self.vitesse_course
        self.compteuranimation  = (self.compteuranimation+1)%10

    def Droite(self):
        self.Vitesse_X          = self.vitesse_course
        self.compteuranimation  = (self.compteuranimation+1)%10

    def Gauche(self):
        self.Vitesse_X          = -self.vitesse_course
        self.compteuranimation  = (self.compteuranimation+1)%10

    def DiagHautDroite(self):
        self.Vitesse_X          = self.vitesse_course*cos(pi/4)
        self.Vitesse_Y          = -self.vitesse_course*cos(pi/4)
        self.compteuranimation  = (self.compteuranimation+1)%10

    def DiagBasDroite(self):
        self.Vitesse_X          = self.vitesse_course*cos(pi/4)
        self.Vitesse_Y          = self.vitesse_course*cos(pi/4)
        self.compteuranimation  = (self.compteuranimation+1)%10

    def DiagHautGauche(self):
        self.Vitesse_X          = -self.vitesse_course*cos(pi/4)
        self.Vitesse_Y          = -self.vitesse_course*cos(pi/4)
        self.compteuranimation  = (self.compteuranimation+1)%10

    def DiagBasGauche(self):
        self.Vitesse_X          = -self.vitesse_course*cos(pi/4)
        self.Vitesse_Y          = self.vitesse_course*cos(pi/4)
        self.compteuranimation  = (self.compteuranimation+1)%10

    def TirGauche(self):
        self.animation = 4
##        self.mask = pygame.mask.from_surface(self.hitboxgauche)
        if classe_balle.Vitesse_X < 0:
            if self.timer_attaque == 0:
                self.timer_attaque = self.timer_attaque_limite
                if pygame.sprite.collide_mask(self,classe_balle):
                    Hit.play()
                    classe_balle.Vitesse_X = -1*classe_balle.Vitesse_X + 1 + randint(-1,1) + abs(self.Vitesse_X)
                    if classe_balle.Vitesse_Y < 0:
                        classe_balle.Vitesse_Y = -1*classe_balle.Vitesse_Y

    def TirDroite(self):
        self.animation = 3
##        self.mask = pygame.mask.from_surface(self.hitboxgauche)
        if classe_balle.Vitesse_X < 0:
            if self.timer_attaque == 0:
                self.timer_attaque = self.timer_attaque_limite
                if pygame.sprite.collide_mask(self,classe_balle):
                    Hit.play()
                    classe_balle.Vitesse_X = -1*classe_balle.Vitesse_X + 1 + randint(-1,1) + abs(self.Vitesse_X)
                    if classe_balle.Vitesse_Y > 0:
                        classe_balle.Vitesse_Y = -1*classe_balle.Vitesse_Y

    def Super(self):
        if self.super >= self.super_limite:
            self.animation = 3
            self.super = 0
            if classe_balle.Vitesse_X < 0:
                if self.timer_attaque == 0:
                    self.timer_attaque = self.timer_attaque_limite
                    if pygame.sprite.collide_mask(self,classe_balle):
                        Super_Hit.play()
                        classe_balle.Vitesse_X = -1*classe_balle.Vitesse_X + 9
                        if randrange(0,2,1) == 0:
                            classe_balle.Vitesse_Y = abs(classe_balle.Vitesse_Y) + 4
                        else:
                            classe_balle.Vitesse_Y = -abs(classe_balle.Vitesse_Y) - 4
                        classe_balle.super_on = True

    def affiche(self,surface):

        surface.blit(self.imgOmbre,self.position.move(-7,25))
        surface.blit(self.image[self.animation],self.position)
##        surface.blit(self.hitboxgauche,self.position)
##        surface.blit(self.hitboxdroite,self.position.move(0,20))
        self.position = self.position.move(self.Vitesse_X,self.Vitesse_Y)
        self.rect     = self.position
        if self.timer_attaque > 0:
            self.timer_attaque -= 1

        if self.super >= self.super_limite:
            pygame.draw.ellipse(self.lumiere,(0,0,int((self.intensite_lumiere)*sin(self.n))+105),(0,0,15,30))
            surface.blit(self.lumiere,self.position.move(1,1),None,BLEND_RGB_ADD)
            self.n += 0.05

        #timer attaque
        if self.timer_attaque > 0:
            self.timer_attaque -= 1

        #Vitesse
        if self.Vitesse_X > 0:
            self.Vitesse_X -= 1
        elif self.Vitesse_X < 0:
            self.Vitesse_X  += 1
        if self.Vitesse_Y > 0:
            self.Vitesse_Y -= 1
        elif self.Vitesse_Y < 0:
            self.Vitesse_Y  += 1

        #Limites Terrain
        if self.position[0] > 140:
            self.position[0] -= self.vitesse_course
        elif self.position[0] < 0:
            self.position[0] += self.vitesse_course
        if self.position[1] < 20:
            self.position[1] += self.vitesse_course
        elif self.position[1] > 150:
            self.position[1] -= self.vitesse_course

        #Animations
        if abs(self.Vitesse_X) <1  and abs(self.Vitesse_Y) < 1:
            self.animation = 0
        else: self.animation = (self.compteuranimation)//5 + 1

class Glibili_Classe:
    def __init__(self):
        self.x                  = 250
        self.y                  = 100
        self.animation          = 0
        self.compteuranimation  = 0
        self.image              = Glibili
        self.position           = Glibili[self.animation].get_rect().move(self.x,self.y)
        self.rect               = Glibili[self.animation].get_rect().move(self.x,self.y)
        self.imgOmbre           = pygame.Surface((32,8))
        self.imgOmbre.fill((70,70,70))
        self.imgOmbre.set_colorkey((70,70,70))
        pygame.draw.ellipse(self.imgOmbre,(0,0,0),(0,0,32,8))
        self.imgOmbre.set_alpha(120)
        self.moncul             = 0
        self.vitesse_course     = 3
        self.Vitesse_X          = 0
        self.Vitesse_Y          = 0
        self.hitboxgauche       = pygame.Surface((30,40))
        self.hitboxgauche.fill((255,0,0))
        self.hitboxdroite       = pygame.Surface((20,10))
        self.hitboxdroite.fill((0,255,0))
        self.timer_attaque      = 0
        self.timer_attaque_limite = 10
        self.mask               = pygame.mask.from_surface(self.hitboxgauche)
        self.Score              = 0
        self.super              = 0
        self.super_limite       = 10
        self.lumiere            = pygame.Surface((15,30))
        self.lumiere.fill((0,0,0))
        self.lumiere.set_colorkey((0,0,0))
        self.intensite_lumiere  = 100
        self.n                  = 0
        self.Vision_IA          = 60

    def Haut(self):
        self.Vitesse_Y          = -self.vitesse_course
        self.compteuranimation  = (self.compteuranimation+1)%10

    def Bas(self):
        self.Vitesse_Y          = self.vitesse_course
        self.compteuranimation  = (self.compteuranimation+1)%10

    def Droite(self):
        self.Vitesse_X          = self.vitesse_course
        self.compteuranimation  = (self.compteuranimation+1)%10

    def Gauche(self):
        self.Vitesse_X          = -self.vitesse_course
        self.compteuranimation  = (self.compteuranimation+1)%10

    def DiagHautDroite(self):
        self.Vitesse_X          = self.vitesse_course*cos(pi/4)
        self.Vitesse_Y          = -self.vitesse_course*cos(pi/4)
        self.compteuranimation  = (self.compteuranimation+1)%10

    def DiagBasDroite(self):
        self.Vitesse_X          = self.vitesse_course*cos(pi/4)
        self.Vitesse_Y          = self.vitesse_course*cos(pi/4)
        self.compteuranimation  = (self.compteuranimation+1)%10

    def DiagHautGauche(self):
        self.Vitesse_X          = -self.vitesse_course*cos(pi/4)
        self.Vitesse_Y          = -self.vitesse_course*cos(pi/4)
        self.compteuranimation  = (self.compteuranimation+1)%10

    def DiagBasGauche(self):
        self.Vitesse_X          = -self.vitesse_course*cos(pi/4)
        self.Vitesse_Y          = self.vitesse_course*cos(pi/4)
        self.compteuranimation  = (self.compteuranimation+1)%10

    def TirGauche(self):
        self.animation = 3
##        self.mask = pygame.mask.from_surface(self.hitboxgauche)
        if classe_balle.Vitesse_X > 0:
            if self.timer_attaque == 0:
                self.timer_attaque = self.timer_attaque_limite
                if pygame.sprite.collide_mask(self,classe_balle):
                    Hit.play()
                    classe_balle.Vitesse_X = -1*classe_balle.Vitesse_X - 1 + randint(-1,1) - abs(self.Vitesse_X)
                    if classe_balle.Vitesse_Y > 0:
                        classe_balle.Vitesse_Y = -1*classe_balle.Vitesse_Y

    def TirDroite(self):
        self.animation = 4
##        self.mask = pygame.mask.from_surface(self.hitboxdroite)
        if classe_balle.Vitesse_X > 0:
            if self.timer_attaque == 0:
                self.timer_attaque = self.timer_attaque_limite
                if pygame.sprite.collide_mask(self,classe_balle):
                    Hit.play()
                    classe_balle.Vitesse_X = -1*classe_balle.Vitesse_X - 1 + randint(-1,1) - abs(self.Vitesse_X)
                    if classe_balle.Vitesse_Y < 0:
                        classe_balle.Vitesse_Y = -1*classe_balle.Vitesse_Y

    def Super(self):
        if self.super >= self.super_limite:
            self.animation = 3
            self.super = 0
            if classe_balle.Vitesse_X > 0:
                if self.timer_attaque == 0:
                    self.timer_attaque = self.timer_attaque_limite
                    if pygame.sprite.collide_mask(self,classe_balle):
                        Super_Hit.play()
                        classe_balle.Vitesse_X = -1*classe_balle.Vitesse_X - 9
                        if randrange(0,2,1) == 0:
                            classe_balle.Vitesse_Y = abs(classe_balle.Vitesse_Y) + 4
                        else:
                            classe_balle.Vitesse_Y = -abs(classe_balle.Vitesse_Y) - 4
                        classe_balle.super_on = True

    def IA(self):
        if classe_balle.Vitesse_X > 0:
            if classe_balle.position[1] > self.position[1]:
                if self.position[0] - classe_balle.position[0] < self.Vision_IA:
                    self.Bas()
                if pygame.sprite.collide_mask(self,classe_balle):
                    if self.super >= self.super_limite:
                        Super_Hit.play()
                        self.Super()
                    elif randrange(0,2,1) == 0:
                        self.TirGauche()
                    else:
                        self.TirDroite()
            else:
                if self.position[0] - classe_balle.position[0] < self.Vision_IA:
                    self.Haut()
                if pygame.sprite.collide_mask(self,classe_balle):
                    if self.super == self.super_limite:
                        self.Super()
                    elif randrange(0,2,1) == 0:
                        self.TirGauche()
                    else:
                        self.TirDroite()
        else:
            if self.position[1] > 90:
                self.Haut()
            elif self.position[1] < 80:
                self.Bas()
        if abs(classe_balle.Vitesse_X) <= 2 and classe_balle.position[0] - self.position[0] < 0:
            self.Gauche()
        else: self.Droite()


    def affiche(self,surface):
        surface.blit(self.imgOmbre,self.position.move(-7,25))
        surface.blit(pygame.transform.flip(self.image[self.animation],1,0),self.position)
        self.position = self.position.move(self.Vitesse_X,self.Vitesse_Y)
        self.rect     = self.position
        if self.timer_attaque > 0:
            self.timer_attaque -= 1

        if self.super >= self.super_limite:
            pygame.draw.ellipse(self.lumiere,(0,0,int((self.intensite_lumiere)*sin(self.n))+105),(0,0,15,30))
            surface.blit(self.lumiere,self.position.move(3,0),None,BLEND_RGB_ADD)
            self.n += 0.05

        #Vitesse
        if self.Vitesse_X > 0:
            self.Vitesse_X -= 1
        elif self.Vitesse_X < 0:
            self.Vitesse_X  += 1
        if self.Vitesse_Y > 0:
            self.Vitesse_Y -= 1
        elif self.Vitesse_Y < 0:
            self.Vitesse_Y  += 1

        #Limites Terrain
        if self.position[0] < 160:
            self.position[0] += self.vitesse_course
        elif self.position[0] > 300:
            self.position[0] -= self.vitesse_course
        if self.position[1] < 20:
            self.position[1] += self.vitesse_course
        elif self.position[1] > 150:
            self.position[1] -= self.vitesse_course

        #Animations
        if abs(self.Vitesse_X) <1  and abs(self.Vitesse_Y) < 1:
            self.animation = 0
        else: self.animation = (self.compteuranimation)//5 + 1

class Balle_Classe(pygame.sprite.Sprite):
    def __init__(self):
        self.x                  = 150
        self.y                  = 145
        self.image              = balle
        self.position           = balle.get_rect().move(self.x,self.y)
        self.rect               = balle.get_rect().move(self.x,self.y)
        self.direction          = randrange(-1,2,2)
        self.angle              = pi/randint(3,6)
        self.Vitesse_X          = self.direction*sin(self.angle)
        self.Vitesse_Y          = -2*cos(self.angle)
        self.vitesse_balle      = 1
        self.compteurTrumpy     = 0
        self.compteurRotation   = 0
        self.mask               = pygame.mask.from_surface(self.image)
        self.super_on           = False

    def affiche(self,surface):
        surface.blit(self.image,self.position)
        self.position = self.position
        self.rect = self.position

        self.x += self.Vitesse_X
        self.y += self.Vitesse_Y
        self.position.topleft = (self.x,self.y)


        # Animation Bras Trumpy
        self.compteurTrumpy += 1
        if self.compteurTrumpy > 10:
            self.direction = 0

        #Rotation de la balle
        self.compteurRotation += 1
        if self.compteurRotation > 10 - self.vitesse_balle:
            self.image = pygame.transform.rotate(self.image,90)
            self.compteurRotation = 0

        #Limites Terrain
        if self.position[1] < 30:
            self.Vitesse_Y = -self.Vitesse_Y
        elif self.position[1] > 165:
            self.Vitesse_Y = -self.Vitesse_Y

        if self.position[0] < -20:
            classe_Glibili.Score += 1
            classe_Alicia.super  += 1
            if classe_Glibili.Vision_IA > 50:
                classe_Glibili.Vision_IA -= 5
            self.__init__()
        elif self.position[0] > 320:
            classe_Alicia.Score  += 1
            classe_Glibili.super += 1
            classe_Glibili.Vision_IA += 5
            self.__init__()

class credits_classe():
    def __init__(self):
        self.xTitre = 45
        self.yTitre = 40
        self.police = pygame.font.Font('PF_Font.ttf',14)

    def Affiche(self,surface):
##        surface.blit(Titre.render("Merci d'avoir joué à module 2",0,(255,255,255)),(self.xTitre,self.yTitre))
        surface.blit(self.police.render("D'après une idée originale de Alexandre Devos",0,(255,255,255)),(self.xTitre-30,self.yTitre+30))
        surface.blit(self.police.render("Producer                   Alexandre Devos",0,(255,255,255)),(self.xTitre-30,self.yTitre+60))
        surface.blit(self.police.render("Head Programmer            Alexandre Devos",0,(255,255,255)),(self.xTitre-30,self.yTitre+90))
        surface.blit(self.police.render("Lead Game Design           Alexandre Devos",0,(255,255,255)),(self.xTitre-30,self.yTitre+120))
        surface.blit(self.police.render("Sound Design               Alexandre Devos",0,(255,255,255)),(self.xTitre-30,self.yTitre+150))
        surface.blit(self.police.render("Composer                   Alexandre Devos",0,(255,255,255)),(self.xTitre-30,self.yTitre+180))
        surface.blit(self.police.render("Art Director               Alexandre Devos",0,(255,255,255)),(self.xTitre-30,self.yTitre+210))
        surface.blit(self.police.render("Quality Control            Alexandre Devos",0,(255,255,255)),(self.xTitre-30,self.yTitre+240))

        surface.blit(self.police.render("Avec la participation de ",0,(255,255,255)),(self.xTitre-30,self.yTitre+270))
        surface.blit(self.police.render("Lucas Kosinski             Effets spéciaux",0,(255,255,255)),(self.xTitre-30,self.yTitre+300))
        surface.blit(self.police.render("                           Glibili",0,(255,255,255)),(self.xTitre-30,self.yTitre+330))
        surface.blit(self.police.render("                           Escargod",0,(255,255,255)),(self.xTitre-30,self.yTitre+360))
        surface.blit(self.police.render("Et ses conseils avisés",0,(255,255,255)),(self.xTitre-30,self.yTitre+390))

        surface.blit(self.police.render("Remerciements ",0,(255,255,255)),(self.xTitre-30,self.yTitre+420))
        surface.blit(self.police.render("Theo Leonard               Incroyable",0,(255,255,255)),(self.xTitre-30,self.yTitre+450))
        surface.blit(self.police.render("                           Cornichon",0,(255,255,255)),(self.xTitre-30,self.yTitre+480))

        surface.blit(self.police.render("Vincent Maille             Edupython",0,(255,255,255)),(self.xTitre-30,self.yTitre+510))
        surface.blit(self.police.render("                           Magic Vinny",0,(255,255,255)),(self.xTitre-30,self.yTitre+540))

        surface.blit(self.police.render("Merci d'avoir joué à module 2",0,(255,255,255)),(self.xTitre+10,self.yTitre+600))

        self.yTitre -= 0.4

class Intro():
    def __init__(self):
        self.x  = 300
        self.y  = 70
        self.AnimPorcoRosso = 1
        self.surface = pygame.Surface((500,50))
        self.surface.fill((255,255,255))
        self.police = pygame.font.Font('PF_Font.ttf',24)
        pygame.draw.rect(self.surface,(0,0,0),(0,0,499,49),2)
        self.surface.blit(self.police.render("  Illapsum Studio Presents          Module 2",0,(0,0,0)),(0,15))

    def Affiche(self,surface):
        surface.blit(Porco_rosso[self.AnimPorcoRosso],(self.x,self.y))
        surface.blit(self.surface,(self.x+50,self.y))

        self.x -= 1

#_Initialisation_#############################################################_#
classe_terrain = terrain()
classe_Alicia  = Alicia_Classe()
classe_Glibili = Glibili_Classe()
classe_balle   = Balle_Classe()
classe_credits = credits_classe()
classe_Intro   = Intro()